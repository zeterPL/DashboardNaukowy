BAR_CHART = "bar-chart"
LINE_CHART = "line-chart"

SELECT_ALL_CATEGORIES_BUTTON = "select-all-categories-button"
CATEGORY_DROPDOWN = "category-dropdown"

# SELECT_ALL_MONTHS_BUTTON = "select-all-months-button"
# MONTH_DROPDOWN = "month-dropdown"

SELECT_ALL_INSTITUTIONS_BUTTON = "select-all-institutions-button"
INSTITUTION_DROPDOWN = "institution-dropdown"

YEAR_DROPDOWN = "year-dropdown"
SELECT_ALL_YEARS_BUTTON = "select-all-years-button"


INPUT_DATA = "input-data"
SEARCH_INPUT_BUTTON = "submit-input-button"
SUBMIT_BUTTON_NEW_QUERRY_DATABASE = "submit-button-new-querry-database"
SUBMIT_RESULT_MESSAGE = "submit-result-message"